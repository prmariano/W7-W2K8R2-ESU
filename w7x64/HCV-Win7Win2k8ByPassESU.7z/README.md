# How to use:
1. Save the script as download.bat and wget.exe in any folder.
2. Run the script download.bat in command prompt.
3. Use install script PreESU-Install.bat to install without ESU License.
4. (Optional) Use install script PosESU-Install.bat to install ONLY WITH ESU License.

# Service Pack 1 is Requirement
1. If need, remove "rem " in line 1 on the download.bat script.
